import UIKit
import PlaygroundSupport
import AVFoundation

class IntroViewController: UIViewController{
    var ImageView = UIImageView()
    var tapHere = UIImageView()
    var soundURI: URL?
    var audioPlayer = AVAudioPlayer()
    var bgSoundURI: URL?
    var bgAudioPlayer = AVAudioPlayer()
    
    override func loadView() {
        playBgSound()
        playIntroSound()
        
        let view = UIView(frame: CGRect(x: 10, y: 50, width: 800, height: 600))
        self.view = view
        navigationController?.isNavigationBarHidden = true
        
        
        // Main Background
        let mainBG = UIImageView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))
        mainBG.image = UIImage(named: "bg4")
        mainBG.contentMode = .scaleAspectFit
        mainBG.isUserInteractionEnabled = true
        view.addSubview(mainBG)
        
        let opening = UIImage(named: "Qur'an")
        ImageView = UIImageView(frame: CGRect(x: 280, y: 115, width: 250, height: 200))
        ImageView.image = opening
        view.addSubview(ImageView)
        
        let tapImg = UIImage(named: "tap")
        tapHere = UIImageView(frame: CGRect(x: 530, y: 400, width: 40, height: 40))
        tapHere.image = tapImg
        view.addSubview(tapHere)
        
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(nextImage(_:)))
        mainBG.addGestureRecognizer(tap)
        
        
    }
    
    // make a sound
    public func playSound(file: String, fileExtension: String, isLoop: Bool = false){
        soundURI = URL(fileURLWithPath: Bundle.main.path(forResource: file, ofType: fileExtension)!)
        do {
            guard let uri = soundURI else {return}
            audioPlayer = try AVAudioPlayer(contentsOf: uri)
            audioPlayer.play()
        } catch {
            // couldn't load file :(
        }
    }
    
    public func playTouchSound(){
        self.playSound(file: "touch_sound", fileExtension: "mp3")
    }
    
    public func playIntroSound(){
        self.playSound(file: "intro", fileExtension: "mp3")
    }
    
    func playBgSound(){
        bgSoundURI = URL(fileURLWithPath: Bundle.main.path(forResource: "backsound", ofType: "mp3")!)
        do {
            guard let uri = bgSoundURI else {return}
            bgAudioPlayer = try AVAudioPlayer(contentsOf: uri)
            bgAudioPlayer.numberOfLoops = -1
            bgAudioPlayer.play()
        } catch {
            print("something went wrong")
        }
    }
    
    func stopBgSound() {
        bgAudioPlayer.stop()
    }
    
    // move to next page
    @objc func nextImage(_ sender: UIPinchGestureRecognizer){
        playTouchSound()
        let coba = detailSurah(scene: view)
        PlaygroundPage.current.liveView = coba
        
    }
    
}

//view live playground
let viewController = IntroViewController()
PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = viewController
