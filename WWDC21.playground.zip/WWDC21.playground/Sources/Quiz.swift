import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

struct question {
    var qImage = String()
    var Answer = Int()
}

public class QuizSurah: UIView{
    
    // MARK: Let's define the world!
    var imgcloud1 = UIImageView()
    var imgcloud2 = UIImageView()
    var imgcloud3 = UIImageView()
    var btnHome = UIButton()
    
    // MARK: Let's define the quiz attribute
    var qImageView = UIImageView()
    var btnTrue = UIButton()
    var btnFalse = UIButton()
    
    var Questions = [question]()
    var qNumber: Int = 0
    var selectedAnswer:Int = 0
    var correct: Int = 0
    var audioPlayer: AVPlayer!
    
    // MARK: Popup Result Properties
    var transparentLayer: UIView = {
        let m_view = UIView(frame: UIScreen.main.bounds)
        m_view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        return m_view
    }()
    
    var popUpSucces: UIView = {
        let popUpSucces = UIButton(frame: CGRect(x: 250, y: 50, width: 300, height: 450))
        popUpSucces.setImage(UIImage(named: "succes"), for: .normal)
        popUpSucces.contentMode = .scaleAspectFit
        return popUpSucces
    }()
    
    var popUpOpss: UIView = {
        let popUpOpss = UIButton(frame: CGRect(x: 250, y: 50, width: 300, height: 450))
        popUpOpss.setImage(UIImage(named: "opss"), for: .normal)
        popUpOpss.contentMode = .scaleAspectFit
        return popUpOpss
    }()
    
    var btnTryAgain: UIButton = {
        let button = UIButton(frame: CGRect(x: 340, y: 420, width: 120, height: 40))
        button.setImage(UIImage(named: "try"), for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    

    public init(scene: UIView) {
        super.init(frame:CGRect(x: 10, y: 0, width: 800, height: 600))
        
        Questions = [question(qImage: "q_cow", Answer: 0), question(qImage: "q_ant", Answer: 1), question(qImage: "q_women", Answer: 0)]
        
        // Background
        let mainBG = UIImageView(frame: CGRect(x: -20, y: 0, width: 800, height: 600))
        mainBG.image = UIImage(named: "bg3")
        mainBG.contentMode = .scaleAspectFit
        self.addSubview(mainBG)
        
        // back to main page
        btnHome = UIButton(frame: CGRect(x: 0, y: 20, width: 129, height: 45))
        btnHome.setImage(UIImage(named: "btnHome"), for: .normal)
        self.addSubview(btnHome)
                
        // image quiz
        updateQuestion()
        
        // make cloud animate
        let cloud1 = UIImage(named: "cloud1")
        imgcloud1 = UIImageView(frame: CGRect(x: 485, y: 110, width: 200, height: 50))
        imgcloud1.image = cloud1
        self.addSubview(imgcloud1)
        
        _ = UIImage(named: "cloud2")
        imgcloud2 = UIImageView(frame: CGRect(x: 20, y: 65, width: 200, height: 50))
        imgcloud2.image = cloud1
        self.addSubview(imgcloud2)
        
        _ = UIImage(named: "cloud3")
        imgcloud3 = UIImageView(frame: CGRect(x: 115, y: 80, width: 200, height: 50))
        imgcloud3.image = cloud1
        self.addSubview(imgcloud3)
        
        UIView.animate(withDuration: 4.0, delay: 0, options: [.autoreverse, .repeat]){
            self.imgcloud1.frame = CGRect(x: 510, y: 110, width: 200, height: 50)
            self.imgcloud2.frame = CGRect(x: 45, y: 65, width: 200, height: 50)
            self.imgcloud3.frame = CGRect(x: 85, y: 80, width: 200, height: 50)
        }

        
        
        // btn option answer
        btnTrue = UIButton(frame: CGRect(x: 175, y: 455, width: 450, height: 40))
        btnTrue.setImage(UIImage(named: "btnTrue"), for: .normal)
        self.addSubview(btnTrue)
        
        btnFalse = UIButton(frame: CGRect(x: 175, y: 510, width: 450, height: 40))
        btnFalse.setImage(UIImage(named: "btnfalse"), for: .normal)
        self.addSubview(btnFalse)
        
        btnTrue.tag = 0
        btnTrue.addTarget(self, action: #selector(btnTrue(_:)), for: .touchUpInside)
        btnFalse.tag = 1
        btnFalse.addTarget(self, action: #selector(btnFalse(_:)), for: .touchUpInside)
        btnHome.addTarget(self, action: #selector(btnHome(_:)), for: .touchUpInside)
        btnTryAgain.addTarget(self, action: #selector(btnTryAgain(_:)), for: .touchUpInside)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func playTouchSound(){
        let url = Bundle.main.url(forResource: "touch_sound", withExtension: "mp3")
        audioPlayer = AVPlayer.init(url: url!)
        audioPlayer.play()
    }
    
    func playCorrectSound(){
        let url = Bundle.main.url(forResource: "correct", withExtension: "mp3")
        audioPlayer = AVPlayer.init(url: url!)
        audioPlayer.play()
    }
    
    func playWrongSound(){
        let url = Bundle.main.url(forResource: "wrong", withExtension: "mp3")
        audioPlayer = AVPlayer.init(url: url!)
        audioPlayer.play()
    }
    
    @objc func btnTrue(_ sender: UIButton){
        if sender.tag == selectedAnswer{
            print("correct")
            self.playCorrectSound()
            correct += 1
            updateQuestion()
        } else{
            print("wrong")
            self.playWrongSound()
            updateQuestion()
        }
    }
    
    @objc func btnFalse(_ sender: UIButton){
        if sender.tag == selectedAnswer{
            print("correct")
            self.playCorrectSound()
            correct += 1
            updateQuestion()
        } else{
            print("wrong")
            self.playWrongSound()
            updateQuestion()
        }
    }
    
    func updateQuestion() {
        if qNumber < Questions.count {
            let imgQuestion = UIImage(named: Questions[qNumber].qImage)
            qImageView = UIImageView(frame: CGRect(x: 145, y: 50, width: 450, height: 400))
            qImageView.image = imgQuestion
            selectedAnswer = Questions[qNumber].Answer
            
            self.addSubview(qImageView)
            qNumber += 1
        } else {
            if correct == Questions.count{
                print("done")
                self.addSubview(transparentLayer)
                self.addSubview(popUpSucces)
                valueAnswer()
            } else{
                self.addSubview(transparentLayer)
                self.addSubview(popUpOpss)
                self.addSubview(btnTryAgain)
                valueAnswer()
            }
            
        }
    }
    
    @objc func btnTryAgain(_ sender: UIButton){
        print("try again")
        self.playTouchSound()
        let coba = QuizSurah(scene: self)
        PlaygroundPage.current.liveView = coba
    }
    
    func valueAnswer()  {
        let labelCorrect = UILabel(frame: CGRect(x: 300, y: 355, width: 40, height: 40))
        labelCorrect.text = "\(correct)"
        
        let labelWrong = UILabel(frame: CGRect(x: 395, y: 355, width: 40, height: 40))
        labelWrong.text = "\(Questions.count - correct)"
        
        let point = UILabel(frame: CGRect(x: 465, y: 357, width: 65, height: 40))
        point.text = "\(Float(correct) * 33.3)"
        
        let fontURL = Bundle.main.url(forResource: "D-DIN-Bold", withExtension: "ttf")
        CTFontManagerRegisterFontsForURL(fontURL! as CFURL, CTFontManagerScope.process, nil)
        let font = UIFont(name: "D-DIN-Bold", size: 30.0)!
        
        labelCorrect.font = font
        labelCorrect.textColor = .black
        self.addSubview(labelCorrect)
        
        labelWrong.font = font
        labelWrong.textColor = .red
        self.addSubview(labelWrong)
        
        point.font = font
        point.textColor = .black
        self.addSubview(point)
    }
    
    @objc func btnHome(_ sender: UIButton){
        print("back to detail")
        self.playTouchSound()
        let coba = detailSurah(scene: self)
        PlaygroundPage.current.liveView = coba
    }
}
