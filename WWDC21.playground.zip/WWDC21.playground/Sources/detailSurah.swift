import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

struct infoSurah {
    var iImg = String()
    var iSound = String()
}

public class detailSurah: UIView{
    // MARK: Let's define the detail attribute
    var details = [infoSurah]()
    var iNumber: Int = 0
    
    var buttonNext = UIButton()
    var buttonBack = UIButton()
    var buttonQuiz = UIButton()
    var infoImageView = UIImageView()
    var audioPlayer: AVPlayer!
    
    public init(scene: UIView) {
        super.init(frame:CGRect(x: 10, y: 50, width: 800, height: 600))
        
        details = [infoSurah(iImg: "i_AlFatihah", iSound: "Al-Fatihah"),
                   infoSurah(iImg: "i_AlBaqarah", iSound: "Al-Baqarah"),
                   infoSurah(iImg: "i_AlImran", iSound: "Al-Imran"),
                   infoSurah(iImg: "i_women", iSound: "An-Nisa"),
                   infoSurah(iImg: "i_AlMaidah", iSound: "Al-Maidah")]
        
        
        // Main Background
        let mainBG = UIImageView(frame: CGRect(x: 0, y: 0, width: 800, height: 600))
        mainBG.image = UIImage(named: "bg1")
        mainBG.contentMode = .scaleAspectFit
        self.addSubview(mainBG)
        
        // navigate to quiz page
        buttonQuiz = UIButton(frame: CGRect(x: 0, y: 20, width: 129, height: 45))
        buttonQuiz.setImage(UIImage(named: "btnQuiz"), for: .normal)
        self.addSubview(buttonQuiz)
        
        nextInfo()
        
        // Button to next or back preview
        buttonNext = UIButton(frame: CGRect(x: 510, y: 270, width: 80, height: 80))
        buttonNext.setImage(UIImage(named: "nextButton"), for: .normal)
        self.addSubview(buttonNext)
        
        buttonBack = UIButton(frame: CGRect(x: 190, y: 270, width: 80, height: 80))
        buttonBack.setImage(UIImage(named: "backButton"), for: .normal)
       self.addSubview(buttonBack)
        
        // action button
        buttonNext.addTarget(self, action: #selector(buttonNext(_:)), for: .touchUpInside)
        buttonBack.addTarget(self, action: #selector(buttonBack(_:)), for: .touchUpInside)
        buttonQuiz.addTarget(self, action: #selector(buttonQuiz(_:)), for: .touchUpInside)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // MARK: Sound to tap button
    func playTouchSound(){
        let url = Bundle.main.url(forResource: "touch_sound", withExtension: "mp3")
        audioPlayer = AVPlayer.init(url: url!)
        audioPlayer.play()
    }
    
    
    @objc func buttonNext(_ sender: UIButton){
        //next or back info surah
        self.playTouchSound()
        iNumber += 1
        print("next")
        nextInfo()
    }
    
    @objc func buttonBack(_ sender: UIButton){
        //next or back info surah
        self.playTouchSound()
        iNumber -= 1
        print("back")
        nextInfo()
    }
    
    // MARK: move to next info surah
    func nextInfo() {
        if iNumber >= 0 && iNumber < details.count{
            let info = UIImage(named: details[iNumber].iImg)
            infoImageView = UIImageView(frame: CGRect(x: 315, y: 250, width: 150, height: 125))
            infoImageView.image = info
            self.addSubview(infoImageView)
            
            let sound = Bundle.main.url(forResource: details[iNumber].iSound, withExtension: "mp3")
            audioPlayer = AVPlayer.init(url: sound!)
            audioPlayer.play()
        } else{
            print("done")
        }
    }
    
    // MARK: Move to next page
    @objc func buttonQuiz(_ sender: UIButton){
        
        print("to quiz")
        self.playTouchSound()
        let coba = QuizSurah(scene: self)
        PlaygroundPage.current.liveView = coba
        
    }
}
